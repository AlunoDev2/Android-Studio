package com.example.myapplication3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViagemActivity extends AppCompatActivity {

    EditText edtDistancia, edtConsumo, edtPrecoGasolina, edtPrecoEtanol;
    Button btnCalcular;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viagem);

        edtDistancia = findViewById(R.id.edtDistancia);
        edtConsumo = findViewById(R.id.edtConsumo);
        edtPrecoGasolina = findViewById(R.id.edtPrecoGasolina);
        edtPrecoEtanol = findViewById(R.id.edtPrecoEtanol);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.txtResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String distanciaStr = edtDistancia.getText().toString();
                String consumoStr = edtConsumo.getText().toString();
                String precoGasolinaStr = edtPrecoGasolina.getText().toString();
                String precoEtanolStr = edtPrecoEtanol.getText().toString();

                if (!distanciaStr.isEmpty() && !consumoStr.isEmpty() &&
                        !precoGasolinaStr.isEmpty() && !precoEtanolStr.isEmpty()) {

                    double distancia = Double.parseDouble(distanciaStr);
                    double consumo = Double.parseDouble(consumoStr);
                    double precoGasolina = Double.parseDouble(precoGasolinaStr);
                    double precoEtanol = Double.parseDouble(precoEtanolStr);

                    double litrosNecessarios = distancia / consumo;
                    double custoGasolina = litrosNecessarios * precoGasolina;
                    double custoEtanol = litrosNecessarios * precoEtanol;

                    txtResultado.setText(String.format("Custo com Gasolina: R$ %.2f\nCusto com Etanol: R$ %.2f", custoGasolina, custoEtanol));
                }
            }
        });
    }
}