package com.example.myapplication3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CashBackActivity extends AppCompatActivity {

    EditText edtCompra;
    Button btnCalcular;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cash_back);

        edtCompra = findViewById(R.id.edtCompra);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.txtResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String compraStr = edtCompra.getText().toString();
                if (!compraStr.isEmpty()) {
                    double compra = Double.parseDouble(compraStr);
                    double percentualCashback;

                    if (compra < 100) {
                        percentualCashback = 0.05; // 5%
                    } else if (compra <= 500) {
                        percentualCashback = 0.10; // 10%
                    } else {
                        percentualCashback = 0.15; // 15%
                    }

                    double cashback = compra * percentualCashback;
                    txtResultado.setText(String.format("CashBack: R$ %.2f (%.0f%%)", cashback, percentualCashback * 100));
                }
            }
        });
    }
}